
function validateForm(){
	var fname = document.getElementById("first-name").value,
    lname = document.getElementById("last-name").value,
	bday = document.getElementById("birthday").value,
	gender = document.getElementsByName("gender"),
	eml = document.getElementById("email").value,
	usrtel = document.getElementById("usrtel").value;
	
	var formValid = true;
	var strValidationMessage = "";
	
	// trebuie sa verificati ca fname are minim 3 charactere si maxim 20 -> folositi fname.length
	console.log("First-name:"+fname);
	console.log(fname.length);
	
	// trebuie sa verificati ca fname are minim 3 charactere si maxim 20
	console.log("Last-name:"+lname);
	
	console.log("Birthday:"+bday);
	// verificam daca bday are char - ; daca nu are are nici macar un char - atunci adaugam mesajul "Birthday is not valid" la mesajul de eroare si formValid = false
	// indexof intoarce pozitia ultimei aparitii a unei valori specificate intr-un string. Daca nu gaseste acea valoare rezultatul av fi -1.
	// http://www.w3schools.com/jsref/jsref_lastindexof.asp
	if (bday.indexOf('-') === -1){
	  strValidationMessage += "Birthday is not valid."
	  formValid = false;
	}
	// split va imparti un sir intr-un array, mai multe informatii gasiti aici: http://www.w3schools.com/jsref/jsref_split.asp
	// de exemplu arrBday[0] va fi anul si trebuie sa aiba 4 charactere 
	var arrBday = bday.split("-");
	// trebuie sa verificati ca anul are 4 cifre, luna 2 (de la 1 la 12) si luna 2 cifre (de la 1 la 31)
	// de exemplu arrBday
	for (var i=0;i<arrBday.length;i++){
		console.log(arrBday[i].length);
	}
	
	// verificati ca userul a selectat female sau male
	for (var i=0;i<gender.length;i++){
		if (gender[i].checked){
			console.log("Gender:"+gender[i].value);
		}	
	}
	
	// verificati ca eml contine caracterul @ (in unele browsere se verifica automat, dat fiindca avem input type=email
	console.log("Email:"+eml);
	
	// verificati ca avem numar -> puteti folosi functia isNaN, uitati-va in consola ce face, sau aici: http://www.w3schools.com/jsref/jsref_isnan.asp
	console.log("User telephone:"+usrtel);
	console.log(isNaN(usrtel));
	
	// daca formValid = false afisam mesajul de eroare si prevenim submitul paginei, altfel mergem in submitted.html
	if (formValid == false){
		alert(strValidationMessage);
		return false;
	} else{
		window.location.href = "submitted.html" ;
		return false;
	}
	
};